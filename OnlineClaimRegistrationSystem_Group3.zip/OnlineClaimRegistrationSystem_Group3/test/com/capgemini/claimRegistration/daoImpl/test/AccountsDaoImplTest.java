package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.AccountsDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Accounts;
import com.capgemini.claimRegistration.model.Policy;

public class AccountsDaoImplTest {
	
	AccountsDaoImpl accountsDao = null; 

	@Before
	public void setUp() throws Exception {
		accountsDao = new AccountsDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		accountsDao = null; 
	}

	@Test
	public void testGetPolicyListNot() {
		List<Policy> list=new ArrayList<>(); 
		try {
			list =accountsDao.getPolicyList("Kabir");
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetPolicyList() {
		List<Policy> list=new ArrayList<>(); 
		try {
			list =accountsDao.getPolicyList("Aman");
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetAllAccounts() {
		List<Accounts> list=new ArrayList<>(); 
		try {
			list =accountsDao.getAllAccounts("Kabir");
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	@Test
	public void testGetAllAccountsNot() {
		List<Accounts> list=new ArrayList<>(); 
		try {
			list =accountsDao.getAllAccounts("Kabir");
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

}
