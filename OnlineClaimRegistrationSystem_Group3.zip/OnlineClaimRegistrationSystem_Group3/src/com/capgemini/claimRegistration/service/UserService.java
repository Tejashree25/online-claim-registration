package com.capgemini.claimRegistration.service;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;

public interface UserService {
	Boolean validateUser(UserRole user)throws ClaimException;
	String getRoleCode(UserRole user)throws ClaimException;

	boolean isValidUsername(String username)throws ClaimException;

	boolean isValidPassword(String profilePassword)throws ClaimException;

	boolean isValidRoleCode(String roleCode)throws ClaimException;

	int profileCreation(UserRole newUser) throws ClaimException;
}
