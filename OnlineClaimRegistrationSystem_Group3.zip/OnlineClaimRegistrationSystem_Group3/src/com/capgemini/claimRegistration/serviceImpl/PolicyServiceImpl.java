package com.capgemini.claimRegistration.serviceImpl;

import java.util.List;

import com.capgemini.claimRegistration.dao.AccountsDao;
import com.capgemini.claimRegistration.dao.ClaimDao;
import com.capgemini.claimRegistration.dao.PolicyDetailsDao;
import com.capgemini.claimRegistration.daoImpl.AccountsDaoImpl;
import com.capgemini.claimRegistration.daoImpl.ClaimDaoImpl;
import com.capgemini.claimRegistration.daoImpl.PolicyDetailsDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Policy;
import com.capgemini.claimRegistration.model.PolicyDetails;
import com.capgemini.claimRegistration.service.PolicyService;

public class PolicyServiceImpl implements PolicyService {
	ClaimDao claimDao = new ClaimDaoImpl();
	PolicyDetailsDao policyDetails = new PolicyDetailsDaoImpl();
	AccountsDao account = new AccountsDaoImpl();
	
	@Override
	public List<Policy> viewPolicies(long accountNumber) throws ClaimException {
		return claimDao.viewPolicies(accountNumber);
	}

	@Override
	public boolean isPolicyExists(long policyNumber, List<Policy> policies)
			throws ClaimException {
		boolean flag = false;

		for (Policy policy : policies) {
			if (policy.getPolicyNumber() == policyNumber) {
				flag = true;
			}
		}
		return flag;
	}
	
	@Override
	public int insertPolicyDetails(PolicyDetails details) throws ClaimException {
		return policyDetails.insertPolicyDetails(details);
	}
	
	@Override
	public List<Policy> getPolicyList(String userName) throws ClaimException {
	
		return account.getPolicyList(userName);
	}
	
	
	@Override
	public boolean isPolicyNumber(long policyNumber) throws ClaimException {
		
		return claimDao.checkPolicyNumber(policyNumber);
	}

	@Override
	public List<Policy> getPolicyList() throws ClaimException {
		
		return claimDao.getPolicyList();
	}


	@Override
	public List<PolicyDetails> getPolicyDetails(long claimNumber)
			throws ClaimException {
		
		return policyDetails.getPolicyDetails(claimNumber);
	}
}
