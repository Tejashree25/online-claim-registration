package com.capgemini.claimRegistration.dao;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.UserRole;

public interface LoginDao {

	Boolean validateUser(UserRole user) throws ClaimException;

	String getRoleCode(UserRole user) throws ClaimException;

}
