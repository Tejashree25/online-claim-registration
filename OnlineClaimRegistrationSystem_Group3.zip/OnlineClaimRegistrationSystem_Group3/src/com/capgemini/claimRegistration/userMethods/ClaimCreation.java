package com.capgemini.claimRegistration.userMethods;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.ClaimQuestions;
import com.capgemini.claimRegistration.model.PolicyDetails;
import com.capgemini.claimRegistration.model.UserRole;
import com.capgemini.claimRegistration.service.ClaimService;
import com.capgemini.claimRegistration.service.PolicyService;
import com.capgemini.claimRegistration.serviceImpl.ClaimServiceImpl;
import com.capgemini.claimRegistration.serviceImpl.PolicyServiceImpl;
import com.capgemini.claimRegistration.userRole.ClaimAdjuster;
import com.capgemini.claimRegistration.userRole.ClaimHandler;
import com.capgemini.claimRegistration.userRole.Insured;

public class ClaimCreation {

	Scanner scanner = null;
	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();
	ClaimAdjuster create = new ClaimAdjuster();
	ClaimHandler handler = new ClaimHandler();
	Insured insured = new Insured();

	public void createNewClaim(long policyNumber, UserRole user)
			throws ClaimException {
		String claimReason = "";
		String accidentLocation = "";
		String accidentCity = "";
		String accidentState = "";
		long accidentZip = 0;
		String claimType = "";

		boolean claimFlag = false;

		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter claim reason or enter 0 to go back to previous menu");

			claimReason = scanner.nextLine();

			claimFlag = service.isValidClaimReason(claimReason);
			if (!claimFlag) {
				if (claimReason.equals("0")) {
					if (user.getRoleCode().equals("CLAIM_HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}
				} else {
					System.err
							.println("Claim reason should have letters only,first letter should be capital and range should be between 5-30.");

				}
			}
		} while (!claimFlag);

		claimFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter Accident location or enter 0 to go back to previous menu:");

			accidentLocation = scanner.nextLine();
			claimFlag = service.isValidAccidentLocation(accidentLocation);
			if (!claimFlag) {
				if (accidentLocation.equals("0")) {
					if (user.getRoleCode().equals("CLAIM_HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}

				} else {
					System.err
							.println("Accident location should have first letter capital or a number and range in between 5-40.");
				}

			}

		} while (!claimFlag);

		claimFlag = false;

		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter city where accident occurred or enter 0 to go back to previous menu:");

			accidentCity = scanner.nextLine();
			claimFlag = service.isValidAccidentCity(accidentCity);
			if (!claimFlag) {
				if (accidentCity.equals("0")) {
					if (user.getRoleCode().equals("CLAIM_HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}
				} else {
					System.err
							.println("City should have letters only, first letter should be capital and range should be between 3-15.");

				}

			}
		} while (!claimFlag);

		claimFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out
					.println("Enter state where accident occurred or enter 0 to go back to previous menu:");

			accidentState = scanner.nextLine();
			claimFlag = service.isValidAccidentState(accidentState);
			if (!claimFlag) {
				if (accidentState.equals("0")) {
					if (user.getRoleCode().equals("CLAIM_HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}
				} else {
					System.err
							.println("Accident state should have letters only, first letter should be capitaland range should be between 3-15.");

				}

			}
		} while (!claimFlag);

		claimFlag = false;
		do {
			scanner = new Scanner(System.in);
			try {

				System.out
						.println("Enter zip code of the area where accident occurred or enter 0 to go back to previous menu:");

				accidentZip = scanner.nextLong();
				claimFlag = service.isValidAccidentZip(accidentZip);
				if (!claimFlag) {
					if (accidentZip == 0l) {
						System.out.println(user.getRoleCode());
						if (user.getRoleCode().equals("CLAIM_HANDLER")) {
							handler.agentMethods(user);

						} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
							create.admin(user);

						} else {
							insured.insuredMethods(user);
						}

					} else {
						System.err
								.println("Zip code should have exactly 5 digits.");

					}

				}
			} catch (InputMismatchException e) {
				System.err.println("Digits only allowed.Enter again.");
				claimFlag = false;
			}

		} while (!claimFlag);

		claimFlag = false;

		do {
			scanner = new Scanner(System.in);

			try {
				System.out
						.println("Select a claim type or enter 0 to go back to previous menu:");
				System.out.println("1.Accident");
				System.out.println("2.Property damage");
				System.out.println("3.Natural Calamities");
				System.out.println("4.Theft");
				System.out.println("Enter your choice:");
				int choice = scanner.nextInt();

				switch (choice) {
				case 0:
					if (user.getRoleCode().equals("CLAIM_HANDLER")) {
						handler.agentMethods(user);

					} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
						create.admin(user);

					} else {
						insured.insuredMethods(user);
					}
					break;
				case 1:
					claimType = "Accident";
					claimFlag = true;
					break;
				case 2:
					claimType = "Property damage";
					claimFlag = true;
					break;
				case 3:
					claimType = "Natural Calamities";
					claimFlag = true;
					break;

				case 4:
					claimType = "Theft";
					claimFlag = true;
					break;
				default:
					System.err.println("Enter in range 1-4.");
					claimFlag = false;
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Enter digits only.");
				claimFlag = false;
			}

		} while (!claimFlag);

		Claim claim = new Claim(claimReason, accidentLocation, accidentCity,
				accidentState, accidentZip, claimType, policyNumber);
		boolean choiceFlag = false;
		long claimNumber = 0l;
		scanner.nextLine();
		
		do {
			System.out
					.println("Enter YES to answer the questions and create claim, NO to exit the application and 0 to go back to previous menu");
			
			String choiceContinue = scanner.nextLine();
			if (choiceContinue.equals("0")) {
				if (user.getRoleCode().equals("CLAIM_HANDLER")) {
					handler.agentMethods(user);

				} else if (user.getRoleCode().equals("CLAIM_ADJUSTER")) {
					create.admin(user);

				} else {
					insured.insuredMethods(user);
				}

			} else if (choiceContinue.equalsIgnoreCase("NO")) {
				System.err.println("Thank you, visit again");
				System.exit(0);
			} else if (choiceContinue.equalsIgnoreCase("YES")) {
				choiceFlag = true;
				PolicyDetails details = new PolicyDetails();
				int answerChoice = 0;
				boolean answerChoiceFlag = false;
				List<ClaimQuestions> questions = new ArrayList<ClaimQuestions>();
				questions = service.getAllClaimQuestions(policyNumber);
				System.out.println("Please answer the given questions:");
				for (ClaimQuestions claimQuestions : questions) {

					details.setQuestionID(claimQuestions.getQuesId());
					details.setPolicyNumber(policyNumber);

					System.out.println(claimQuestions.getQuesDesc());
					System.out.println("1. " + claimQuestions.getQuesAns1()
							+ " 2." + claimQuestions.getQuesAns2());

					do {
						scanner = new Scanner(System.in);

						try {

							System.out
									.println("Enter 1 for yes or 2 for no or 0 to go back to previous menu:");

							answerChoice = scanner.nextInt();
							answerChoiceFlag = true;

							switch (answerChoice) {
							case 0:

								if (user.getRoleCode().equals("CLAIM_HANDLER")) {
									handler.agentMethods(user);

								} else if (user.getRoleCode().equals(
										"CLAIM_ADJUSTER")) {
									create.admin(user);

								} else {
									insured.insuredMethods(user);
								}

								break;
							case 1:
								details.setAnswer(claimQuestions.getQuesAns1());
								break;

							case 2:
								details.setAnswer(claimQuestions.getQuesAns2());
								break;

							default:
								System.err.println("Enter only 1 or 2");
								answerChoiceFlag = false;
								break;
							}
							policyService.insertPolicyDetails(details);

						} catch (InputMismatchException e) {
							answerChoiceFlag = false;
							System.err.println("Enter only 1 or 2");
						}
					} while (!answerChoiceFlag);

				}
				claimNumber = service.insertClaimDetails(claim);
			} else {
				System.err.println("Enter YES or NO only");
				choiceFlag = false;
			}
		} while (!choiceFlag);

		System.out.println("Claim Details Inserted With Claim Number :"
				+ claimNumber);

	}

}
