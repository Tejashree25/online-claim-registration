package com.cg.tej.model;

public class PolicyDetails {
	private Long policyNumber;
	private Integer questionID;
	private String answer;

	public PolicyDetails() {
		// TODO Auto-generated constructor stub
	}

	public PolicyDetails(Long policyNumber, Integer questionID, String answer) {
		super();
		this.policyNumber = policyNumber;
		this.questionID = questionID;
		this.answer = answer;
	}

	public Long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Integer getQuestionID() {
		return questionID;
	}

	public void setQuestionID(Integer questionID) {
		this.questionID = questionID;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
}
