package com.cg.tej.daoimpl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.tej.dao.ClaimCheckDao;
import com.cg.tej.dao.ClaimCreateDao;
import com.cg.tej.model.Claim;

/**
 * Servlet implementation class ClaimCreate
 */
@WebServlet("/ClaimCreate")
public class ClaimCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClaimCreate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	    String n1=request.getParameter("policyn");
	    System.out.println(n1);
	    Long n=Long.parseLong(request.getParameter("policyn"));
	    System.out.println(n);
	    String reason=request.getParameter("reason");
	    System.out.println(reason);
	    String location=request.getParameter("location");
	    System.out.println(location);
	    String city=request.getParameter("city");
	    System.out.println(city);
	    String state=request.getParameter("state");
	    System.out.println(state);
	    Long zip=Long.parseLong(request.getParameter("zip"));
	    System.out.println(zip);
	    String ctype=request.getParameter("ctype");
	    System.out.println(ctype);
	    Claim claim = new Claim(reason,location,city,state,zip,ctype,n);
	    
	    
	    if(ClaimCreateDao.create(claim)){  
	    	String txt1 = "Claim data is processing";
	    	out.println("<script type=\"text/javascript\">alert('"+txt1+"');");
	    	out.println("location='admin2.jsp'");
	    	out.println("</script>");
	    	RequestDispatcher rd=request.getRequestDispatcher("ClaimQuestion.jsp");  
	        rd.forward(request,response); 
	    }  
	    else{  
	    	
	    	String txt1 = "Error better try after some time";
	    	out.println("<script type=\"text/javascript\">alert('"+txt1+"');");
	    	out.println("location='admin2.jsp'");
	    	out.println("</script>");
	    }  
	          
	    out.close();  
	    }  
		
	}
