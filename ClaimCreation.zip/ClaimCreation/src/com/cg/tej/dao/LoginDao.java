package com.cg.tej.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.tej.dao.QueryMapper;
import com.cg.tej.model.UserRole;
import com.cg.tej.utility.JDBCutility;

public class LoginDao {
	public static boolean validate(UserRole user) {
		boolean status = false;
		
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.logIn);
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
	public static String getRoleCode(UserRole user) {
		String role="";
		
		try {
				Connection con = JDBCutility.getConnection();
				PreparedStatement ps = con.prepareStatement("select role_code from user_role where user_name=?");
				ps.setString(1, user.getUserName());
				ResultSet rs1 = ps.executeQuery();
				rs1.next();
				role = rs1.getString(1);
				System.out.println(role);
			} catch (Exception e) {
				System.out.println(e);
		}
		return role;
	}
	
}
