package com.cg.tej.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.tej.model.UserRole;
import com.cg.tej.utility.JDBCutility;

public class AccountDao {
	public static long getaccountNo(UserRole ur) {
		long account=0;
		
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.insuredaccount);
			ps.setString(1, ur.getUserName());
			ResultSet rs = ps.executeQuery();
			rs.next();
			account =Long.parseLong(rs.getString(1));
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return account;
	}
	public static long getpolicyNo(long accno) {
		long policy=0;
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.insuredpolicy1);
			ps.setLong(1, accno);
			ResultSet rs = ps.executeQuery();
			rs.next();
			policy =Long.parseLong(rs.getString(1));
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return policy;
	}
	public static long getclaimNo(long policy) {
		long claim=0;
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.insuredclaim);
			ps.setLong(1, policy);
			ResultSet rs = ps.executeQuery();
			rs.next();
			claim =Long.parseLong(rs.getString(1));
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return claim;
	}
}
