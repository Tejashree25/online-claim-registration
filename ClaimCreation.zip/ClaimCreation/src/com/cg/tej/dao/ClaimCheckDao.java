package com.cg.tej.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.tej.model.Claim;
import com.cg.tej.utility.JDBCutility;

public class ClaimCheckDao {
	public static boolean validate(Claim claim) {
		boolean status = false;
		
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.checkClaim);
			ps.setLong(1, claim.getPolicyNumber());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

}
