package com.cg.tej.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.tej.model.PolicyDetails;
import com.cg.tej.utility.JDBCutility;

public class ClaimQuestionDAO {
	public static boolean inserta(PolicyDetails pd) {
		boolean status = false;
		
		try {
			
			Connection con = JDBCutility.getConnection();
			PreparedStatement ps = con.prepareStatement(QueryMapper.insertpolicydetail);
			ps.setLong(1, pd.getPolicyNumber());
			ps.setInt(2, pd.getQuestionID());
			ps.setString(3, pd.getAnswer());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
			
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

}
