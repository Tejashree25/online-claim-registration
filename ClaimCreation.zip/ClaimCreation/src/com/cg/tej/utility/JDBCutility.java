package com.cg.tej.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCutility {
	public static Connection getConnection() {
	Connection connection = null;
	String driverName = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String username = "TEJASHREE";
	String password = "tejashree";
	
	//1.Load the JDBC driver.
	try {
		Class.forName(driverName);
	}catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	//2. Create connection to the database
	try {
		connection = DriverManager.getConnection(url, username, password);
		System.out.println("connection established.....");
	}catch (SQLException e) {
      e.printStackTrace();
	}
	return connection;
	}
}
