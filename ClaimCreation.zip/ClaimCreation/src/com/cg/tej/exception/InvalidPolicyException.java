package com.cg.tej.exception;

public class InvalidPolicyException extends Exception{
	public InvalidPolicyException(String s){  
		  super(s);  
	}  
}
