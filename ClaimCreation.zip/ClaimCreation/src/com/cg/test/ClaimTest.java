package com.cg.test;

import static org.junit.Assert.assertTrue;
import com.cg.tej.model.UserRole;
import static org.junit.jupiter.api.Assertions.*;
import com.cg.tej.dao.LoginDao;
import org.junit.jupiter.api.Test;


class ClaimTest {

	@Test
	public void testValidLogIn() {
		UserRole user=new UserRole("Teju", "Teju123@","INSURED");
		try {
			boolean userRole=LoginDao.validate(user);
			assertTrue(userRole);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void testgetRoleCode() {
		UserRole user=new UserRole("Teju", "Teju123@","INSURED");
		try {
			String userRole=LoginDao.getRoleCode(user);
			assertEquals(userRole,"INSURED");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
