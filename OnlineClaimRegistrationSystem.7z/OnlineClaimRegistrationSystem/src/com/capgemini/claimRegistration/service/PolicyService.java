package com.capgemini.claimRegistration.service;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Policy;
import com.capgemini.claimRegistration.model.PolicyDetails;

public interface PolicyService {
	List<Policy> viewPolicies(long accountNumber) throws ClaimException;

	boolean isPolicyExists(long policyNumber, List<Policy> policies)
			throws ClaimException;

	int insertPolicyDetails(PolicyDetails details) throws ClaimException;

	List<Policy> getPolicyList(String userName) throws ClaimException;

	boolean isPolicyNumber(long policyNumber) throws ClaimException;

	List<Policy> getPolicyList() throws ClaimException;

	List<PolicyDetails> getPolicyDetails(long claimNumber)
			throws ClaimException;

}
