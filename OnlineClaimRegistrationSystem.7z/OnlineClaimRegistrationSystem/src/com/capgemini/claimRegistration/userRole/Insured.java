package com.capgemini.claimRegistration.userRole;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Policy;
import com.capgemini.claimRegistration.model.UserRole;
import com.capgemini.claimRegistration.service.ClaimService;
import com.capgemini.claimRegistration.service.PolicyService;
import com.capgemini.claimRegistration.serviceImpl.ClaimServiceImpl;
import com.capgemini.claimRegistration.serviceImpl.PolicyServiceImpl;
import com.capgemini.claimRegistration.ui.Main;
import com.capgemini.claimRegistration.userMethods.ClaimCreation;
import com.capgemini.claimRegistration.userMethods.ViewClaim;

public class Insured {
	Scanner scanner = null;
	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();

	public void insuredMethods(UserRole user) throws ClaimException {

		boolean insuredFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println();
			System.out.println("***************INSURED MENU***************");
			System.out.println();
			System.out.println("1.Claim Creation");
			System.out.println("2.View Claim");
			System.out.println("3.LOGOUT");
			System.out.println("4.Exit");
			System.out.println("Enter your Choice");
			try {
				int choice = scanner.nextInt();
				switch (choice) {

				case 1:
					List<Policy> policies = new ArrayList<>();
					scanner = new Scanner(System.in);

					policies = policyService.getPolicyList(user.getUserName());

					if (policies.isEmpty()) {
						System.err
								.println(user.getUserName()
										+ " does not have a policy.Policy is required for claim creation.");

					} else {

						boolean policyFlag = false;
						long policyNumber = 0l;
						do {
							System.out.println();
							System.out.println("Policies you have:");
							System.out.printf("%10s %20s %20s",
									"Policy Number", "Policy Type",
									"Policy Premium");
							System.out.println();
							for (Policy policy : policies) {
								System.out.printf("%10s %20s %20s\n",
										policy.getPolicyNumber(),
										policy.getPolicyType(),
										policy.getPolicyPremium());
							}

							scanner = new Scanner(System.in);
							System.out
									.println("Select Policy Number from above list or enter 0 to go back to previous menu: ");

							try {
								policyNumber = scanner.nextLong();

								if (policyNumber == 0l) {
									policyFlag = true;
									insuredFlag = false;
								} else {

									boolean isPolicyExists = policyService
											.isPolicyExists(policyNumber,
													policies);

									if (!isPolicyExists) {
										policyFlag = false;
										System.err
												.println("Given Policy Number does not exist, Select Policy Number from the given List");
									} else {
										policyFlag = true;

										boolean checkFlag = policyService
												.isPolicyNumber(policyNumber);
										if (checkFlag == false) {
											ClaimCreation claimCreation = new ClaimCreation();
											claimCreation.createNewClaim(
													policyNumber, user);
										} else {
											System.err
													.println("Claim already created for the policy number:"
															+ policyNumber);

										}
									}
								}
							} catch (InputMismatchException e) {
								policyFlag = false;
								System.err
										.println("Policy Number should be digits only");
							}
						} while (!policyFlag);

					}

					break;

				case 2:
					ViewClaim viewClaim = new ViewClaim();
					viewClaim.showInsuredClaim(user.getUserName());
					break;

				case 3:
					System.err
							.println("You have successfully logged off from your account");
					insuredFlag = true;
					Main.login();
					break;

				case 4:
					System.err.println("Thank you,visit again");
					System.exit(0);
					break;
				default:
					insuredFlag = false;
					System.err.println("Choice should be between 1 to 4");
				}

			} catch (InputMismatchException e) {
				insuredFlag = false;
				System.err.println("Enter digits only");
			}

		} while (!insuredFlag);

	}

}
