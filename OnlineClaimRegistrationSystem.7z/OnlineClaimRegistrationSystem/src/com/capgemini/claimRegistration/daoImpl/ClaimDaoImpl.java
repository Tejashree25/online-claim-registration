package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.ClaimDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.Policy;

public class ClaimDaoImpl implements ClaimDao {
	static Logger logger = Logger.getLogger(ClaimDaoImpl.class);

	/**
	 * method name : viewPolicies argument : accountNumber class object return
	 * type : List<Policy> author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the account number as an argument and
	 * returns the List of policy to the user
	 */

	@Override
	public List<Policy> viewPolicies(long accountNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Policy> policies = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");

		try {
			statement = connection.prepareStatement(QueryMapper.viewPolicy);
			logger.info("connection established..");
			statement.setLong(1, accountNumber);

			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long policyNumber = set.getLong("POLICY_NUMBER");

				String policyType = set.getString("POLICY_TYPE");

				double premium = set.getDouble("POLICY_PREMIUM");

				long accountNo = set.getLong("ACCOUNT_NUMBER");

				Policy policy = new Policy();
				policy.setPolicyNumber(policyNumber);
				policy.setPolicyPremium(premium);
				policy.setAccountNumber(accountNo);
				policy.setPolicyType(policyType);

				policies.add(policy);
				logger.info("policy added to the list " + policy);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new ClaimException("Sql exception" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policies;

	}

	/**
	 * method name :insertClaimDetails argument : claim class object return type
	 * : long author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the claim class object as an argument and
	 * returns number of rows inserted in the database
	 */
	@Override
	public long insertClaimDetails(Claim claim) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		Long result = 0l;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.insertClaimQuery);
			logger.info("connection established..");

			statement.setString(1, claim.getClaimReason());

			statement.setString(2, claim.getAccidentLocationStreet());

			statement.setString(3, claim.getAccidentCity());
			statement.setString(4, claim.getAccidentState());
			statement.setLong(5, claim.getAccidentZip());
			statement.setString(6, claim.getClaimType());
			statement.setLong(7, claim.getPolicyNumber());
			statement.executeUpdate();
			logger.info("claim added to the list ");

			preparedStatement = connection
					.prepareStatement(QueryMapper.getClaimNumber);
			set = preparedStatement.executeQuery();
			set.next();
			result = set.getLong(1);

			connection.commit();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();
				preparedStatement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return result;

	}

	/**
	 * method name :getAllClaims return type : long List<Claim> 
	 * Author : Capgemini 
	 * date : 11-03-2019
	 * description : This method returns the List of claims to the user
	 */
	@Override
	public List<Claim> getAllClaims() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		List<Claim> claims = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.viewClaimQuery);
			logger.info("connection established..");
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long claimNumber = set.getLong("CLAIM_NUMBER");
				String claimReason = set.getString("CLAIM_REASON");
				String location = set.getString("ACCIDENT_LOCATION_STREET");
				String city = set.getString("ACCIDENT_CITY");
				String state = set.getString("ACCIDENT_STATE");
				long zip = set.getLong("ACCIDENT_ZIP");
				String claimType = set.getString("CLAIM_TYPE");
				long policyNumber = set.getLong("POLICY_NUMBER");
				Claim claim = new Claim(claimNumber, claimReason, location,
						city, state, zip, claimType, policyNumber);
				claims.add(claim);
				logger.info("claim added to the list " + claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;

	}

	/**
	 * method name :showInsuredClaims argument : Username return type Author :
	 * Capgemini date : 11-03-2019 description : This method will take the
	 * username and returns the List of claim class object
	 */
	@Override
	public List<Claim> showInsuredClaims(String userName) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet set = null;
		long accountNumber = 0l;
		long number = 0l;
		List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getAccountNumberQuery);
			logger.info("connection established..");

			statement.setString(1, userName);
			set = statement.executeQuery();
			logger.info("resultset created");
			boolean result = set.next();
			if (result == true) {
				accountNumber = set.getLong("ACCOUNT_NUMBER");

				preparedStatement = connection
						.prepareStatement(QueryMapper.viewPolicy);
				preparedStatement.setLong(1, accountNumber);
				set = preparedStatement.executeQuery();
				logger.info("resultset created");
				while (set.next()) {
					number = set.getLong("POLICY_NUMBER");
					policyNumbers.add(number);
				}

				for (Long policyNumber : policyNumbers) {

					statement = connection
							.prepareStatement(QueryMapper.viewInsuredClaimQuery);
					logger.info("connection established..");
					statement.setLong(1, policyNumber);
					set = statement.executeQuery();
					while (set.next()) {
						long claimNumber = set.getLong("CLAIM_NUMBER");
						String claimReason = set.getString("CLAIM_REASON");
						String location = set
								.getString("ACCIDENT_LOCATION_STREET");
						String city = set.getString("ACCIDENT_CITY");
						String state = set.getString("ACCIDENT_STATE");
						long zip = set.getLong("ACCIDENT_ZIP");
						String claimType = set.getString("CLAIM_TYPE");
						long policyNumber1 = set.getLong("POLICY_NUMBER");
						Claim claim = new Claim(claimNumber, claimReason,
								location, city, state, zip, claimType,
								policyNumber1);
						claims.add(claim);
						logger.info("policy added to the list " + claim);

					}

				}
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();
				/* preparedStatement.close(); */

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}

	/**
	 * method name :checkPolicyNumber argument : long policyNumber return type:
	 * boolean Author: Capgemini date : 11-03-2019 description : This method
	 * will take policyNumber as an argument and returns whether the policy
	 * number exists or not
	 */
	@Override
	public boolean checkPolicyNumber(long policyNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		boolean validate = false;
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.validatePolicyNumberQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);

			set = statement.executeQuery();
			logger.info("resultset created");
			validate = set.next();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Invalid Credentials" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return validate;
	}

	/**
	 * method name :getPolicyList return type :List Author : Capgemini date :
	 * 11-03-2019 description : This method returns the List of policies to the
	 * user
	 */

	@Override
	public List<Policy> getPolicyList() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");

		List<Policy> policies = new ArrayList<>();

		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.getPolicyListQuery);
			logger.info("connection established..");
			set = statement.executeQuery();
			logger.info("resultset created");

			while (set.next()) {
				long policyNumber = set.getLong("policy_number");
				double premium = set.getDouble("policy_premium");
				long accountNumber = set.getLong("account_number");
				String policyType = set.getString("policy_type");

				Policy policy = new Policy(policyNumber, premium,
						accountNumber, policyType);
				policies.add(policy);
				logger.info("policy added to the list " + policy);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policies;
	}

	/**
	 * method name :showAgentClaims argument : Long policyNumber return type
	 * :List Author: Capgemini date : 11-03-2019 description : This method will
	 * take policyNumber as an argument and returns the List of claim to the
	 * user
	 */

	@Override
	public List<Claim> showAgentClaims(Long policyNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		// long accountNumber = 0l;
		// long number = 0l;
		// List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection
					.prepareStatement(QueryMapper.viewAgentClaimQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");
			while (set.next()) {
				long claimNumber = set.getLong("CLAIM_NUMBER");
				String claimReason = set.getString("CLAIM_REASON");
				String location = set.getString("ACCIDENT_LOCATION_STREET");
				String city = set.getString("ACCIDENT_CITY");
				String state = set.getString("ACCIDENT_STATE");
				long zip = set.getLong("ACCIDENT_ZIP");
				String claimType = set.getString("CLAIM_TYPE");
				long policyNumber1 = set.getLong("POLICY_NUMBER");
				Claim claim = new Claim(claimNumber, claimReason, location,
						city, state, zip, claimType, policyNumber1);
				claims.add(claim);
				logger.info("claim added to the list " + claim);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}

	/**
	 * method name :getClaimDetails argument : long policyNumber return type :
	 * Claim class object Author: Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the model object as an argument and
	 * returns the List of policy numbers to the user
	 */
	@Override
	public Claim getClaimDetails(long policyNumber) throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		Claim claim = new Claim();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.getClaimQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");

			set.next();

			long claimNumber = set.getLong("CLAIM_NUMBER");
			String claimReason = set.getString("CLAIM_REASON");
			String location = set.getString("ACCIDENT_LOCATION_STREET");
			String city = set.getString("ACCIDENT_CITY");
			String state = set.getString("ACCIDENT_STATE");
			long zip = set.getLong("ACCIDENT_ZIP");
			String claimType = set.getString("CLAIM_TYPE");
			long policyNumber1 = set.getLong("POLICY_NUMBER");
			logger.info("policy added to the list ");

			claim = new Claim(claimNumber, claimReason, location, city, state,
					zip, claimType, policyNumber1);

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claim;
	}

	/**
	 * method name :showAgentCustomerClaim argument : long accountNumber return
	 * type List<Claim> Author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take accountNumber as an argument and
	 * returns the List of claim class object to the user
	 */
	@Override
	public List<Claim> showAgentCustomerClaim(long accountNumber)
			throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet set = null;
		long number = 0l;
		List<Long> policyNumbers = new ArrayList<>();
		List<Claim> claims = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {

			statement = connection.prepareStatement(QueryMapper.viewPolicy);
			logger.info("connection established..");
			statement.setLong(1, accountNumber);
			set = statement.executeQuery();
			logger.info("resultset created");
			while (set.next()) {
				number = set.getLong("POLICY_NUMBER");
				policyNumbers.add(number);
			}

			for (Long policyNumber : policyNumbers) {

				statement = connection
						.prepareStatement(QueryMapper.viewInsuredClaimQuery);
				logger.info("connection established..");
				statement.setLong(1, policyNumber);
				set = statement.executeQuery();
				logger.info("resultset created");
				while (set.next()) {
					long claimNumber = set.getLong("CLAIM_NUMBER");
					String claimReason = set.getString("CLAIM_REASON");
					String location = set.getString("ACCIDENT_LOCATION_STREET");
					String city = set.getString("ACCIDENT_CITY");
					String state = set.getString("ACCIDENT_STATE");
					long zip = set.getLong("ACCIDENT_ZIP");
					String claimType = set.getString("CLAIM_TYPE");
					long policyNumber1 = set.getLong("POLICY_NUMBER");
					Claim claim = new Claim(claimNumber, claimReason, location,
							city, state, zip, claimType, policyNumber1);
					claims.add(claim);

					logger.info("claim added to the list " + claim);

				}

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured" + e);
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return claims;
	}

}
