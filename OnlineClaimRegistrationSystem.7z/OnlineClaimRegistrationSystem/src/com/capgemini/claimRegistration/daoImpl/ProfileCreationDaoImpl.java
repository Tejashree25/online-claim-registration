package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.ProfileCreationDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.UserRole;

public class ProfileCreationDaoImpl implements ProfileCreationDao {
	static Logger logger = Logger.getLogger(ReportGenerationDaoImpl.class);


	/**
	 * method name :profileCreation argument : UserRole class object return type
	 * :  int author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the UserRole class object as an argument and
	 * returns the number of rows inserted in the database
	 */


	@Override
	public int profileCreation(UserRole newUser) throws ClaimException {
		logger.info("in ProfileCreationDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			logger.info("connection established..");

			statement.setString(1, newUser.getUserName());

			statement.setString(2, newUser.getPassword());

			statement.setString(3, newUser.getRoleCode());
			result = statement.executeUpdate();
			logger.info("resultset created");
			connection.commit();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException(newUser.getUserName()
					+ " already exists, try with another username");
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return result;

	}

}
