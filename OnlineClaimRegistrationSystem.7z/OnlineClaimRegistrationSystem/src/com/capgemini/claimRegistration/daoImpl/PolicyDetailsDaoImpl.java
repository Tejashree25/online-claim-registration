package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.PolicyDetailsDao;
import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.PolicyDetails;

public class PolicyDetailsDaoImpl implements PolicyDetailsDao {
	static Logger logger = Logger.getLogger(PolicyDetailsDaoImpl.class);

	/**
	 * method name : insertPolicyDetails argument :PolicyDetails class object return type
	 * : int author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the PolicyDetails class object as an argument and
	 * returns number of rows inserted in the database
	 */


	@Override
	public int insertPolicyDetails(PolicyDetails details) throws ClaimException {
		logger.info("In PolicyDetailsDaoImpl  class");
		Connection connection = null;
		PreparedStatement statement = null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		int result = 0;
		try {
			statement = connection.prepareStatement(QueryMapper.insertPolicyDetailsQuery);
			logger.info("connection established..");

			statement.setLong(1, details.getPolicyNumber());
			statement.setInt(2, details.getQuestionID());
			statement.setString(3, details.getAnswer());
			result = statement.executeUpdate();
			logger.info("resultset created");
			connection.commit();

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("sql exception occured"+e);
					
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return result;
	}
	
	/**
	 * method name :  getPolicyDetails argument :policyNumber return type
	 * : List<PolicyDetails> author : Capgemini date : 11-03-2019
	 * 
	 * description : This method will take the policyNumber as an argument and
	 * returns the details of policies based on policy number
	 */
	@Override
	public List<PolicyDetails> getPolicyDetails(long policyNumber)
			throws ClaimException {
		logger.info("in PolicyDetailsDaoImpl class");
		
		Connection connection = null;
		PreparedStatement statement = null;
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		ResultSet set = null;
		List<PolicyDetails> policies = new ArrayList<>();
		try {
			statement = connection.prepareStatement(QueryMapper.getPolicyDetailsQuery);
			logger.info("connection established..");
			statement.setLong(1, policyNumber);
			set = statement.executeQuery();
			logger.info("resultset created");
			connection.commit();
			while (set.next()) {
				long number = set.getLong("POLICY_NUMBER");
				int qId = set.getInt("QUESTION_ID");
				String answer = set.getString("ANSWER");
				
				PolicyDetails policyDetails = new PolicyDetails(number, qId, answer);
				policies.add(policyDetails);
				
			}
			

		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("sql exception occured"+e);
					
		} finally {
			try {
				// closing statement
				statement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing statement.");
			}

			try {
				// closing connection
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());

				System.err.println("Error while closing connection.");
			}
		}

		return policies;
	}

}
