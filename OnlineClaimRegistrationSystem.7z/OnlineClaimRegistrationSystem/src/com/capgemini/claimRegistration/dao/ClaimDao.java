package com.capgemini.claimRegistration.dao;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;
import com.capgemini.claimRegistration.model.Policy;

public interface ClaimDao {

	List<Policy> viewPolicies(long accountNumber) throws ClaimException;

	long insertClaimDetails(Claim claim)throws ClaimException;

	List<Claim> getAllClaims()throws ClaimException;

	List<Claim> showInsuredClaims(String userName)throws ClaimException;

	boolean checkPolicyNumber(long policyNumber)throws ClaimException;

	List<Policy> getPolicyList()throws ClaimException;

	List<Claim> showAgentClaims(Long policyNumber)throws ClaimException;

	Claim getClaimDetails(long claimNumber)throws ClaimException;

	List<Claim> showAgentCustomerClaim(long accountNumber)throws ClaimException;

	

}
