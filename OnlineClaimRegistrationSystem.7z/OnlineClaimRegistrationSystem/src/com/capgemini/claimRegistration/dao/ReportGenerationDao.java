package com.capgemini.claimRegistration.dao;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Claim;

public interface ReportGenerationDao {

	List<Claim> getAllclaimReport() throws ClaimException;

}
