package com.capgemini.claimRegistration.dao;

public interface QueryMapper {

	String viewPolicy="select * from policy where account_number=?";
	
	String insertQuery = "insert into user_role(user_name,password,role_code) values(?,?,?)";

	String validateUser = "select * from user_role where user_name=? and password=?";
	
	String selectRoleCode = "select role_code from user_role where user_name=? and password=?";

	String insertClaimQuery = "insert into claim values(claim_number_seq.nextval,?,?,?,?,?,?,?)";

	String getClaimNumber = "select claim_number_seq.currval from dual";

	String viewClaimQuery = "select * from claim"; 
	
	String viewClaimQuestions = "select * from claim_questions where policy_type in (select policy_type from policy where policy_number=? )";

	String insertPolicyDetailsQuery = "insert into policy_details values(?,?,?)";

	String viewClaimReportQuery = "select * from claim";

	String getAccountNumberQuery = "select account_number from accounts where user_name = ?";
	
	String viewInsuredClaimQuery = "select * from claim where policy_number = ?";

	String validatePolicyNumberQuery = "select * from claim where policy_number = ?";

	String getPolicyListQuery = "select * from policy";

	String getAllAccountsQuery = "select * from accounts where user_name = ?";

	String viewAgentClaimQuery = "select * from claim where policy_number = ?";

	String getClaimQuery = "select * from claim where policy_number=?";

	String getPolicyDetailsQuery = "select * from policy_details where policy_number=?";

	String getClaimQuestionsQuery = "select ques_desc from claim_questions where ques_id = ?"; 
	 
}
