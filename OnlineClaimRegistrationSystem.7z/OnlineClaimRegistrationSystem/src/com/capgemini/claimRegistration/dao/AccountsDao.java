package com.capgemini.claimRegistration.dao;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Accounts;
import com.capgemini.claimRegistration.model.Policy;

public interface AccountsDao {

	List<Policy> getPolicyList(String userName)throws ClaimException;

	List<Accounts> getAllAccounts(String userName)throws ClaimException;

}
